export enum Role {
  STUDENT = 'student',
  INVESTOR = 'investor',
}

export interface UserProfile {
  name: string;
  avatar?: string; // URL or identifier for profile picture
  age?: number;
  gender?: string;
  experience?: string; // e.g., "0-1 years", "2-5 years"

  // Student-specific
  interests?: string;
  skills?: string;
  certifications?: string;
  graduationYear?: string;

  // Investor-specific
  focusAreas?: string;
  company?: string;
  companyMail?: string;
  roleInCompany?: string;
}

export interface User {
  id: string;
  email: string;
  role: Role;
  profile: UserProfile;
  profileComplete: boolean;
  savedIdeas?: StartupIdea[];
  investorFeed?: StartupIdea[];
}

export interface StartupIdea {
  ideaName: string;
  description: string;
  audience: string;
  monetization: string;
  ideaScore: number; // A score from 0-100 indicating viability.
  feasibilityAnalysis: string; // A brief analysis of the idea's feasibility.
  suggestedMentors: {
    name: string;
    expertise: string;
  }[];
  suggestedInvestors: {
    name: string;
    focus: string;
  }[];
  industry: string;
}

export interface GroundingSource {
    uri: string;
    title: string;
}

export interface ChatMessage {
    sender: 'user' | 'ai';
    text: string;
    ideas?: StartupIdea[];
    timestamp: number;
    sources?: GroundingSource[];
}
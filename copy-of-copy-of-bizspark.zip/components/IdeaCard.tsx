import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { StartupIdea, ChatMessage, User, Role } from '../types';
import { generateIdeaFromChat } from '../services/geminiService';
import { LoadingSpinner } from './LoadingSpinner';
import { Layout } from './Footer'; // Repurposed as Layout

// Re-skinned and enhanced IdeaCard component for reuse
export const IdeaCard: React.FC<{ idea: StartupIdea, onSave?: (idea: StartupIdea) => void, isSaved?: boolean, defaultExpanded?: boolean }> = ({ idea, onSave, isSaved, defaultExpanded = false }) => {
    const [isExpanded, setIsExpanded] = useState(defaultExpanded);
    const scoreColor = idea.ideaScore > 75 ? 'text-green-400' : idea.ideaScore > 50 ? 'text-yellow-400' : 'text-red-400';

    const handleSaveClick = (e: React.MouseEvent) => {
        e.stopPropagation(); // Prevents the card from toggling
        onSave?.(idea);
    };

    return (
        <div 
            className="bg-[#001e4c]/70 border border-gray-700 rounded-2xl shadow-xl overflow-hidden p-6 transition-all duration-300 hover:shadow-flame-orange/20 hover:border-flame-orange/50 w-full max-w-2xl mx-auto cursor-pointer"
            onClick={() => setIsExpanded(!isExpanded)}
        >
            {/* Always visible content */}
            <div className="mb-4">
                <div className="flex justify-between items-start">
                    <h2 className="text-2xl font-bold text-flame-orange">{idea.ideaName}</h2>
                    {idea.industry && <span className="text-xs font-semibold px-2 py-1 rounded-full bg-deep-blue text-gray-300 border border-gray-600">{idea.industry}</span>}
                </div>
                <p className="text-md text-gray-300 mt-1">{idea.description}</p>
            </div>
            
            <div className="mb-4">
                <h3 className="font-semibold text-white mb-2">Idea Score: <span className={scoreColor}>{idea.ideaScore}/100</span></h3>
                <div className="w-full bg-gray-700 rounded-full h-2.5">
                    <div className="bg-flame-orange h-2.5 rounded-full" style={{ width: `${idea.ideaScore}%` }}></div>
                </div>
            </div>

            {/* Expandable content */}
            <div className={`grid transition-all duration-500 ease-in-out ${isExpanded ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}>
                <div className="overflow-hidden">
                    <div className="border-t border-gray-700 pt-4 mt-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm mb-4">
                            <div><h4 className="font-semibold text-white mb-1">🎯 Target Audience</h4><p className="text-gray-400">{idea.audience}</p></div>
                            <div><h4 className="font-semibold text-white mb-1">💰 Monetization</h4><p className="text-gray-400">{idea.monetization}</p></div>
                        </div>

                        <div className="mb-4">
                            <h4 className="font-semibold text-white mb-1">🔬 Feasibility Analysis</h4>
                            <p className="text-gray-400 text-sm">{idea.feasibilityAnalysis}</p>
                        </div>
                        <div>
                            <h4 className="font-semibold text-white mb-1">🤝 Suggested Mentors</h4>
                            <ul className="list-disc list-inside text-gray-400 text-sm space-y-1">
                                {idea.suggestedMentors.map((mentor, i) => <li key={i}><strong>{mentor.name}</strong> - {mentor.expertise}</li>)}
                            </ul>
                        </div>
                        {idea.suggestedInvestors && idea.suggestedInvestors.length > 0 && (
                            <div className="mt-4">
                                <h4 className="font-semibold text-white mb-1">💼 Suggested Investors</h4>
                                <ul className="list-disc list-inside text-gray-400 text-sm space-y-1">
                                    {idea.suggestedInvestors.map((investor, i) => <li key={i}><strong>{investor.name}</strong> - {investor.focus}</li>)}
                                </ul>
                            </div>
                        )}
                    </div>
                </div>
            </div>
            
            {/* Footer with save button and hint */}
            <div className="mt-6 flex justify-between items-center">
                <button
                    onClick={handleSaveClick}
                    disabled={!onSave || isSaved}
                    className="bg-flame-orange/20 text-flame-orange font-semibold py-2 px-4 rounded-lg border border-flame-orange transition-colors disabled:bg-gray-600 disabled:text-gray-400 disabled:border-gray-500 enabled:hover:bg-flame-orange enabled:hover:text-white z-10"
                >
                    {isSaved ? 'Saved' : 'Save Idea'}
                </button>
                <div className="text-xs text-gray-500 flex items-center">
                    <span>{isExpanded ? 'Show Less' : 'Show More'}</span>
                    <svg xmlns="http://www.w3.org/2000/svg" className={`h-4 w-4 ml-1 transition-transform duration-300 ${isExpanded ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
                </div>
            </div>
        </div>
    );
};

// Main StudentDashboard component
export const StudentDashboard: React.FC<{ user: User, setUser: (user: User) => void, setView: (view: string) => void, openChatbot: () => void }> = ({ user, setUser, setView, openChatbot }) => {
    const [chatHistory, setChatHistory] = useState<ChatMessage[]>([
        { sender: 'ai', text: `Hi ${user.profile.name}! I'm your BizSpark AI. Tell me about your passions, skills, or any problems you'd like to solve.`, timestamp: Date.now() }
    ]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const chatEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [chatHistory]);

    const handleSaveIdea = (ideaToSave: StartupIdea) => {
        const alreadySaved = user.savedIdeas?.some(i => i.ideaName === ideaToSave.ideaName);
        if (alreadySaved) return;

        const updatedSavedIdeas = [...(user.savedIdeas || []), ideaToSave];
        const updatedUser = { ...user, savedIdeas: updatedSavedIdeas };
        setUser(updatedUser);
    };
    
    const handleSend = useCallback(async () => {
        if (!input.trim() || isLoading) return;

        const userMessage: ChatMessage = { sender: 'user', text: input, timestamp: Date.now() };
        const newChatHistory = [...chatHistory, userMessage];
        setChatHistory(newChatHistory);
        setInput('');
        setIsLoading(true);

        try {
            const aiResponse = await generateIdeaFromChat(newChatHistory);
            setChatHistory(prev => [...prev, aiResponse]);
        } catch (error) {
            const errorResponse: ChatMessage = { sender: 'ai', text: 'Sorry, something went wrong.', timestamp: Date.now() };
            setChatHistory(prev => [...prev, errorResponse]);
        } finally {
            setIsLoading(false);
        }
    }, [input, isLoading, chatHistory]);

    return (
        <Layout currentView="dashboard" setView={setView} openChatbot={openChatbot}>
            <div className="flex flex-col h-full overflow-hidden">
                <div className="flex-grow p-4 overflow-y-auto">
                    <div className="space-y-4">
                        {chatHistory.map((msg) => (
                            <div key={msg.timestamp} className={`flex items-end gap-2 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                                {msg.sender === 'ai' && <div className="w-8 h-8 rounded-full bg-flame-orange flex items-center justify-center font-bold text-white flex-shrink-0">B</div>}
                                <div className={`max-w-lg p-3 rounded-2xl ${msg.sender === 'user' ? 'bg-flame-orange text-white rounded-br-none' : 'bg-[#001e4c] text-gray-200 rounded-bl-none'}`}>
                                    <p className="text-sm" dangerouslySetInnerHTML={{__html: msg.text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')}}/>
                                    {msg.ideas && (
                                        <div className="mt-4 space-y-6">
                                            {msg.ideas.map((idea, index) => (
                                                <IdeaCard
                                                    key={`${msg.timestamp}-${index}`}
                                                    idea={idea}
                                                    onSave={handleSaveIdea}
                                                    isSaved={user.savedIdeas?.some(i => i.ideaName === idea.ideaName)}
                                                    defaultExpanded={true}
                                                />
                                            ))}
                                        </div>
                                    )}
                                </div>
                            </div>
                        ))}
                        {isLoading && (
                             <div className="flex items-end gap-2 justify-start">
                                <div className="w-8 h-8 rounded-full bg-flame-orange flex items-center justify-center font-bold text-white flex-shrink-0">B</div>
                                <div className="max-w-lg p-3 rounded-2xl bg-[#001e4c] text-gray-200 rounded-bl-none">
                                    <LoadingSpinner />
                                </div>
                            </div>
                        )}
                        <div ref={chatEndRef} />
                    </div>
                </div>
                <div className="p-4 bg-deep-blue border-t border-gray-700">
                    <div className="flex items-center bg-[#001e4c] rounded-full p-2">
                        <input
                            type="text"
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                            placeholder="Share your interests and skills..."
                            className="w-full bg-transparent text-white placeholder-gray-400 focus:outline-none px-4"
                        />
                        <button onClick={handleSend} disabled={isLoading} className="bg-flame-orange text-white rounded-full p-2 disabled:bg-orange-800">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" /></svg>
                        </button>
                    </div>
                </div>
            </div>
        </Layout>
    );
};

// Saved Ideas Screen
export const SavedScreen: React.FC<{ user: User, setView: (view: string) => void, openChatbot?: () => void }> = ({ user, setView, openChatbot }) => {
  const isInvestor = user.role === Role.INVESTOR;
  const [sortBy, setSortBy] = useState<'none' | 'score' | 'name'>('none');
  const [filterBy, setFilterBy] = useState<string>('all');

  const industries = useMemo(() => [...new Set(user.savedIdeas?.map(idea => idea.industry).filter(Boolean) as string[])], [user.savedIdeas]);

  const filteredAndSortedIdeas = useMemo(() => {
    let ideas = [...(user.savedIdeas || [])];
    
    if (filterBy !== 'all') {
        ideas = ideas.filter(idea => idea.industry === filterBy);
    }

    if (sortBy === 'score') {
        ideas.sort((a, b) => b.ideaScore - a.ideaScore);
    } else if (sortBy === 'name') {
        ideas.sort((a, b) => a.ideaName.localeCompare(b.ideaName));
    }
    
    return ideas;
  }, [user.savedIdeas, filterBy, sortBy]);

  return (
    <Layout currentView="saved" setView={setView} openChatbot={openChatbot}>
      <div className="p-4 h-full overflow-y-auto">
        <header className="p-4 md:flex justify-between items-center sticky top-0 bg-deep-blue/80 backdrop-blur-sm -mx-4 px-4 z-10">
           <h1 className="text-2xl font-bold text-white mb-4 md:mb-0">Saved {isInvestor ? 'Opportunities' : 'Ideas'}</h1>
           {isInvestor && user.savedIdeas && user.savedIdeas.length > 0 && (
             <div className="flex items-center space-x-2 md:space-x-4">
                <div className="flex items-center space-x-2">
                    <label htmlFor="filter" className="text-gray-300 text-sm">Industry:</label>
                    <select 
                        id="filter" 
                        value={filterBy}
                        onChange={(e) => setFilterBy(e.target.value)}
                        className="bg-[#001e4c] border border-gray-600 rounded-lg p-2 text-white focus:ring-flame-orange text-sm"
                    >
                        <option value="all">All</option>
                        {industries.map(ind => <option key={ind} value={ind}>{ind}</option>)}
                    </select>
                </div>
                <div className="flex items-center space-x-2">
                    <label htmlFor="sort" className="text-gray-300 text-sm">Sort by:</label>
                    <select 
                        id="sort" 
                        value={sortBy}
                        onChange={(e) => setSortBy(e.target.value as any)}
                        className="bg-[#001e4c] border border-gray-600 rounded-lg p-2 text-white focus:ring-flame-orange text-sm"
                    >
                        <option value="none">Default</option>
                        <option value="score">Idea Score</option>
                        <option value="name">Name (A-Z)</option>
                    </select>
                </div>
             </div>
           )}
        </header>
        <main className="container mx-auto py-4">
          {filteredAndSortedIdeas.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredAndSortedIdeas.map((idea, index) => <IdeaCard key={index} idea={idea} isSaved={true} />)}
            </div>
          ) : (
             <div className="text-center text-gray-400 mt-20 flex flex-col items-center">
               <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-gray-500 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" /></svg>
              <h3 className="text-xl font-semibold mb-2">No Saved Ideas Yet</h3>
              <p>Go to your dashboard to generate and save new ideas!</p>
            </div>
          )}
        </main>
      </div>
    </Layout>
  );
};
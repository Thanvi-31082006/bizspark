import { GoogleGenAI, Type } from "@google/genai";
import { StartupIdea, ChatMessage, GroundingSource, UserProfile } from '../types';

if (!process.env.API_KEY) {
    console.warn("API_KEY environment variable not set. App will not function correctly.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

const ideaSchema = {
  type: Type.OBJECT,
  properties: {
    ideaName: {
      type: Type.STRING,
      description: "A creative and catchy name for the startup.",
    },
    description: {
      type: Type.STRING,
      description: "A brief, one-to-two sentence compelling description of the business concept.",
    },
    audience: {
      type: Type.STRING,
      description: "The specific target customer or user base for this idea.",
    },
    monetization: {
      type: Type.STRING,
      description: "The primary strategy for generating revenue (e.g., subscription, freemium, B2B sales).",
    },
    ideaScore: {
        type: Type.INTEGER,
        description: "A score from 0-100 representing the idea's potential, feasibility, and market fit."
    },
    feasibilityAnalysis: {
        type: Type.STRING,
        description: "A short paragraph analyzing the potential challenges and viability of this startup idea."
    },
    suggestedMentors: {
        type: Type.ARRAY,
        description: "A list of 2-3 hypothetical mentor profiles with relevant expertise for this startup.",
        items: {
            type: Type.OBJECT,
            properties: {
                name: { type: Type.STRING, description: "Full name of the suggested mentor." },
                expertise: { type: Type.STRING, description: "A brief description of their relevant skills or industry experience." }
            },
            required: ['name', 'expertise']
        }
    },
    suggestedInvestors: {
        type: Type.ARRAY,
        description: "A list of 2-3 hypothetical investor profiles or VC firms that would be a good fit for this startup.",
        items: {
            type: Type.OBJECT,
            properties: {
                name: { type: Type.STRING, description: "Full name of the investor or name of the VC firm." },
                focus: { type: Type.STRING, description: "A brief description of their investment focus (e.g., 'Early-stage FinTech', 'Seed-stage B2B SaaS')." }
            },
            required: ['name', 'focus']
        }
    },
    industry: {
        type: Type.STRING,
        description: "A single, broad industry category for this idea (e.g., 'FinTech', 'EdTech', 'HealthTech', 'Sustainability')."
    }
  },
  required: ['ideaName', 'description', 'audience', 'monetization', 'ideaScore', 'feasibilityAnalysis', 'suggestedMentors', 'suggestedInvestors', 'industry'],
};

export async function generateIdeaFromChat(chatHistory: ChatMessage[]): Promise<ChatMessage> {
  const userMessages = chatHistory.map(msg => `${msg.sender}: ${msg.text}`).join('\n');

  const prompt = `
    You are BizSpark, an AI co-pilot for student entrepreneurs. Your role is to act as a chatbot, understand the user's skills and interests from the conversation, and generate detailed startup ideas.
    
    Conversation History:
    ${userMessages}

    Your task:
    1.  Analyze the user's latest message in the context of the conversation.
    2.  You MUST generate ideas and respond in JSON format IF:
        a) The user provides enough information about their interests and skills and seems ready for an idea.
        b) The user explicitly asks for more ideas (e.g., "more ideas", "generate another one", "show me something else").
    3.  If you generate ideas, create a list of 2 to 3 diverse, detailed startup ideas. The output MUST be a JSON object that strictly follows the provided schema.
    4.  If the user's message is conversational and DOES NOT meet the criteria in task #2, respond with a friendly, encouraging chat message as text, asking them about their passions, skills, or problems they want to solve. DO NOT output JSON in this case.

    If you generate ideas, ensure they are innovative, viable, and tailored to the user's input from the entire conversation history.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
            type: Type.OBJECT,
            properties: {
                response_type: { type: Type.STRING, description: "Either 'idea' or 'chat'."},
                content: { type: Type.STRING, description: "The chat message if response_type is 'chat'."},
                ideas: {
                    type: Type.ARRAY,
                    description: "A list of 2 to 3 startup ideas based on the user's interests.",
                    items: ideaSchema
                }
            }
        },
        temperature: 0.8,
      },
    });

    const jsonText = response.text.trim();
    const result = JSON.parse(jsonText);

    if (result.response_type === 'idea' && result.ideas && Array.isArray(result.ideas) && result.ideas.length > 0) {
        return {
            sender: 'ai',
            text: `I've sparked a few more ideas for you! Take a look and let me know what you think.`,
            ideas: result.ideas as StartupIdea[],
            timestamp: Date.now()
        };
    } else {
         return {
            sender: 'ai',
            text: result.content || "I'm sorry, I couldn't process that. Could you tell me more about your skills or interests?",
            timestamp: Date.now()
        };
    }

  } catch (error) {
    console.error("Gemini API call failed:", error);
    return {
        sender: 'ai',
        text: "I'm having a little trouble connecting to my creative circuits right now. Please try again in a moment.",
        timestamp: Date.now()
    };
  }
}

export async function generateInvestorFeed(profile: UserProfile): Promise<StartupIdea[]> {
  const prompt = `
    You are an expert venture capital analyst for BizSpark. Your task is to generate a curated list of 5 to 7 innovative startup ideas for an investor.
    
    The investor's profile is as follows:
    - Name: ${profile.name}
    - Investment Focus Areas: ${profile.focusAreas || 'General Technology'}

    The ideas must be a strong match for the investor's focus areas. Ensure the ideas are diverse and cover different aspects within those areas. For each idea, provide all the details required by the schema.

    Your output MUST be a single JSON object containing a key 'ideas' which is an array of these startup ideas. Do not include any other text or markdown.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-pro",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            ideas: {
              type: Type.ARRAY,
              description: "A list of 5 to 7 startup ideas tailored to the investor's profile.",
              items: ideaSchema
            }
          },
          required: ['ideas']
        },
        temperature: 0.7,
      },
    });

    const jsonText = response.text.trim();
    const result = JSON.parse(jsonText);
    
    if (result.ideas && Array.isArray(result.ideas)) {
        return result.ideas as StartupIdea[];
    }
    
    return [];

  } catch (error) {
    console.error("Gemini API call for investor feed failed:", error);
    return [];
  }
}

export type ChatMode = 'quick' | 'deep' | 'search';

export async function getChatbotResponse(chatHistory: ChatMessage[], mode: ChatMode): Promise<ChatMessage> {
    const prompt = chatHistory.map(msg => `${msg.sender}: ${msg.text}`).join('\n');
    
    let model: string;
    const config: any = {};
    let systemInstruction: string = 'You are BizSpark Assistant, an AI helper for student entrepreneurs. Be helpful, encouraging, and provide concise, actionable advice. Format your responses using markdown.';

    switch (mode) {
        case 'deep':
            model = 'gemini-2.5-pro';
            config.thinkingConfig = { thinkingBudget: 32768 };
            systemInstruction += ' The user has requested a deep analysis. Provide a thorough, well-reasoned response.';
            break;
        case 'search':
            model = 'gemini-2.5-flash';
            config.tools = [{ googleSearch: {} }];
            systemInstruction += ' The user is looking for up-to-date information. Use search to find the most relevant and current data and cite your sources.';
            break;
        case 'quick':
        default:
            model = 'gemini-2.5-flash';
            break;
    }
    
    config.systemInstruction = systemInstruction;

    try {
        const response = await ai.models.generateContent({
            model,
            contents: prompt,
            config: config,
        });

        const text = response.text;
        
        let sources: GroundingSource[] | undefined;
        if (mode === 'search' && response.candidates?.[0]?.groundingMetadata?.groundingChunks) {
            sources = response.candidates[0].groundingMetadata.groundingChunks
                .filter(chunk => chunk.web && chunk.web.uri && chunk.web.title)
                .map(chunk => ({
                    uri: chunk.web!.uri!,
                    title: chunk.web!.title!,
                }));
        }

        return {
            sender: 'ai',
            text: text,
            timestamp: Date.now(),
            sources: sources,
        };

    } catch (error) {
        console.error("Gemini API call failed:", error);
        return {
            sender: 'ai',
            text: "I'm having a little trouble connecting right now. Please try again in a moment.",
            timestamp: Date.now()
        };
    }
}
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { ChatMessage } from '../types';
import { getChatbotResponse, ChatMode } from '../services/geminiService';
import { LoadingSpinner } from './LoadingSpinner';
import { ThemeDropIcon } from './ThemeDropIcon';

interface ChatbotProps {
  onClose: () => void;
}

const ModeButton: React.FC<{ active: boolean, onClick: () => void, children: React.ReactNode }> = ({ active, onClick, children }) => (
    <button
        onClick={onClick}
        className={`px-3 py-1 text-sm font-semibold rounded-full transition-colors ${
            active
                ? 'bg-flame-orange text-white'
                : 'bg-deep-blue text-gray-300 hover:bg-gray-700'
        }`}
    >
        {children}
    </button>
);

export const Chatbot: React.FC<ChatbotProps> = ({ onClose }) => {
    const [history, setHistory] = useState<ChatMessage[]>([
        { sender: 'ai', text: "Hello! I'm the BizSpark Assistant. How can I help you today? You can ask me for business advice, market trends, or anything else to help your startup journey.", timestamp: Date.now() }
    ]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [mode, setMode] = useState<ChatMode>('quick');
    const chatEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [history]);

    const handleSend = useCallback(async () => {
        if (!input.trim() || isLoading) return;

        const userMessage: ChatMessage = { sender: 'user', text: input, timestamp: Date.now() };
        const newHistory = [...history, userMessage];
        setHistory(newHistory);
        setInput('');
        setIsLoading(true);

        try {
            const aiResponse = await getChatbotResponse(newHistory, mode);
            setHistory(prev => [...prev, aiResponse]);
        } catch (error) {
            const errorResponse: ChatMessage = { sender: 'ai', text: 'Sorry, something went wrong.', timestamp: Date.now() };
            setHistory(prev => [...prev, errorResponse]);
        } finally {
            setIsLoading(false);
        }
    }, [input, isLoading, history, mode]);

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center p-4 z-50">
            <div className="w-full max-w-2xl h-[90vh] bg-[#001e4c] rounded-2xl shadow-2xl border border-gray-700 flex flex-col overflow-hidden">
                <header className="p-4 border-b border-gray-700 flex justify-between items-center">
                    <div>
                        <h2 className="text-xl font-bold text-white">BizSpark Assistant</h2>
                        <div className="flex items-center space-x-2 mt-2">
                           <ModeButton active={mode === 'quick'} onClick={() => setMode('quick')}>⚡ Quick Chat</ModeButton>
                           <ModeButton active={mode === 'deep'} onClick={() => setMode('deep')}>🧠 Deep Analysis</ModeButton>
                           <ModeButton active={mode === 'search'} onClick={() => setMode('search')}>🌐 Web Search</ModeButton>
                        </div>
                    </div>
                    <button onClick={onClose} className="text-gray-400 hover:text-white">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                    </button>
                </header>

                <div className="flex-grow p-4 overflow-y-auto">
                    <div className="space-y-4">
                        {history.map((msg) => (
                            <div key={msg.timestamp} className={`flex items-end gap-2 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                                {msg.sender === 'ai' && <div className="w-8 h-8 rounded-full bg-deep-blue border border-gray-600 flex items-center justify-center font-bold text-white flex-shrink-0"><ThemeDropIcon className="w-4"/></div>}
                                <div className={`max-w-lg p-3 rounded-2xl prose prose-invert prose-sm ${msg.sender === 'user' ? 'bg-flame-orange text-white rounded-br-none' : 'bg-deep-blue text-gray-200 rounded-bl-none'}`}>
                                    <p dangerouslySetInnerHTML={{ __html: msg.text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br />') }} />
                                    {msg.sources && msg.sources.length > 0 && (
                                        <div className="mt-2 border-t border-gray-600 pt-2">
                                            <h4 className="font-semibold text-xs text-gray-400 mb-1">Sources:</h4>
                                            <ul className="list-disc list-inside space-y-1">
                                                {msg.sources.map((source, index) => (
                                                    <li key={index}>
                                                        <a href={source.uri} target="_blank" rel="noopener noreferrer" className="text-flame-orange text-xs underline hover:text-orange-400">
                                                            {source.title}
                                                        </a>
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                    )}
                                </div>
                            </div>
                        ))}
                        {isLoading && (
                            <div className="flex items-end gap-2 justify-start">
                                <div className="w-8 h-8 rounded-full bg-deep-blue border border-gray-600 flex items-center justify-center font-bold text-white flex-shrink-0"><ThemeDropIcon className="w-4"/></div>
                                <div className="max-w-lg p-3 rounded-2xl bg-deep-blue text-gray-200 rounded-bl-none">
                                    <LoadingSpinner />
                                </div>
                            </div>
                        )}
                        <div ref={chatEndRef} />
                    </div>
                </div>

                <div className="p-4 bg-[#001e4c] border-t border-gray-700">
                    <div className="flex items-center bg-deep-blue rounded-full p-2">
                        <input
                            type="text"
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                            placeholder="Ask me anything..."
                            className="w-full bg-transparent text-white placeholder-gray-400 focus:outline-none px-4"
                            disabled={isLoading}
                        />
                        <button onClick={handleSend} disabled={isLoading || !input.trim()} className="bg-flame-orange text-white rounded-full p-2 disabled:bg-orange-800 transition-colors">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" /></svg>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

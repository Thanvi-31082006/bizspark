import React, { useState, useRef } from 'react';
import { User, Role } from '../types';

// New Layout Component with Bottom Navigation
interface LayoutProps {
  children: React.ReactNode;
  currentView: 'dashboard' | 'saved' | 'opportunities' | 'settings';
  setView: (view: string) => void;
  openChatbot?: () => void;
}

const NavItem: React.FC<{ label: string, icon: React.ReactNode, isActive: boolean, onClick: () => void }> = ({ label, icon, isActive, onClick }) => (
    <button onClick={onClick} className={`flex flex-col items-center justify-center w-full transition-colors duration-200 ${isActive ? 'text-flame-orange' : 'text-gray-400 hover:text-white'}`}>
        {icon}
        <span className="text-xs mt-1">{label}</span>
    </button>
);

export const Layout: React.FC<LayoutProps> = ({ children, currentView, setView, openChatbot }) => {
  const isStudent = localStorage.getItem('bizspark_user') ? JSON.parse(localStorage.getItem('bizspark_user')!).role === 'student' : true;
  const dashboardView = isStudent ? 'studentDashboard' : 'investorDashboard';

  return (
    <div className="h-screen w-screen flex flex-col bg-deep-blue relative">
      <main className="flex-grow overflow-hidden">
        {children}
      </main>

      {isStudent && openChatbot && (
        <button 
          onClick={openChatbot}
          className="absolute bottom-20 right-4 bg-flame-orange text-white rounded-full p-4 shadow-lg hover:bg-orange-600 transition-transform transform hover:scale-110 z-20"
          aria-label="Open BizSpark Assistant"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.293 2.293a1 1 0 010 1.414L10 12l-2.293-2.293a1 1 0 010-1.414L10 6m5 4l2.293-2.293a1 1 0 011.414 0L22 10l-2.293 2.293a1 1 0 01-1.414 0L15 10m-4 11v-4m-2-2h4m-7 4l2.293-2.293a1 1 0 011.414 0L10 22l-2.293-2.293a1 1 0 010-1.414L10 15" /></svg>
        </button>
      )}

      <footer className="flex-shrink-0 bg-[#001e4c] border-t border-gray-700 z-10">
          <div className="flex justify-around items-center h-16">
              <NavItem label="Dashboard" icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>} isActive={currentView === 'dashboard'} onClick={() => setView(dashboardView) } />
              <NavItem label="Saved" icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" /></svg>} isActive={currentView === 'saved'} onClick={() => setView('saved')} />
              <NavItem label="Opportunities" icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.196-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.783-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" /></svg>} isActive={currentView === 'opportunities'} onClick={() => setView('opportunities')} />
              <NavItem label="Settings" icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0 3.35a1.724 1.724 0 001.066 2.573c-.94-1.543.826 3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>} isActive={currentView === 'settings'} onClick={() => setView('settings')} />
          </div>
      </footer>
    </div>
  );
};

const SettingsButton: React.FC<{ onClick: () => void, children: React.ReactNode }> = ({ onClick, children }) => (
    <button onClick={onClick} className="w-full text-left bg-[#001e4c] p-4 rounded-lg hover:bg-opacity-75 transition flex justify-between items-center">
        <span>{children}</span>
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
    </button>
);

// Settings Screen
export const SettingsScreen: React.FC<{ user: User, setView: (view: string) => void, onLogout: () => void }> = ({ user, setView, onLogout }) => {
    const dashboardView = user.role === Role.STUDENT ? 'studentDashboard' : 'investorDashboard';

    const handleHelpSupportClick = () => {
        alert("For help and support, please contact us at: yourbizstartofficial@gmail.com");
    };

    const handleReportIssueClick = () => {
        alert("To report an issue, please email: yourbizstartofficial@gmail.com");
    };

    return (
        <div className="p-4 min-h-screen">
            <header className="flex items-center mb-8">
                 <button onClick={() => setView(dashboardView)} className="mr-4 text-flame-orange">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
                </button>
                <h1 className="text-2xl font-bold">Settings</h1>
            </header>
            <div className="space-y-4">
                <SettingsButton onClick={() => setView('accountDetails')}>Account Details</SettingsButton>
                <SettingsButton onClick={() => setView('notifications')}>Notifications</SettingsButton>
                <SettingsButton onClick={handleHelpSupportClick}>Help & Support</SettingsButton>
                <SettingsButton onClick={handleReportIssueClick}>Report an Issue</SettingsButton>
                <div className="pt-4">
                    <button onClick={onLogout} className="w-full text-center bg-red-600/20 text-red-400 p-3 rounded-lg hover:bg-red-600/40 transition">
                        Log Out
                    </button>
                </div>
            </div>
        </div>
    );
};

// Account Details Screen
export const AccountDetailsScreen: React.FC<{ user: User, setUser: (user: User) => void, setView: (view: string) => void }> = ({ user, setUser, setView }) => {
    const [formData, setFormData] = useState(user.profile);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const isStudent = user.role === Role.STUDENT;

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files?.[0]) {
            const file = e.target.files[0];
            const reader = new FileReader();
            reader.onloadend = () => {
                setFormData(prev => ({ ...prev, avatar: reader.result as string }));
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSave = () => {
        const updatedUser = { ...user, profile: formData };
        setUser(updatedUser);
        alert('Profile saved!');
        setView('settings');
    };

    const inputClass = "w-full bg-deep-blue border border-gray-600 rounded-lg p-3 focus:ring-2 focus:ring-flame-orange focus:border-flame-orange";
    const labelClass = "block text-sm font-medium text-gray-300 mb-2";

    return (
        <div className="p-4 min-h-screen">
             <header className="flex items-center mb-8">
                <button onClick={() => setView('settings')} className="mr-4 text-flame-orange">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
                </button>
                <h1 className="text-2xl font-bold">Account Details</h1>
            </header>
            
            <div className="space-y-6 max-w-lg mx-auto">
                <div className="flex flex-col items-center space-y-2">
                    <input type="file" ref={fileInputRef} onChange={handleAvatarChange} style={{ display: 'none' }} accept="image/*" />
                    <button onClick={() => fileInputRef.current?.click()} className="relative group">
                        <img src={formData.avatar} alt="Profile" className="w-24 h-24 rounded-full object-cover border-2 border-flame-orange" />
                        <div className="absolute inset-0 bg-black bg-opacity-50 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                            <span className="text-white text-sm">Change</span>
                        </div>
                    </button>
                </div>

                <div>
                    <label htmlFor="name" className={labelClass}>Full Name</label>
                    <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} required className={inputClass} />
                </div>
                 <div>
                    <label htmlFor="age" className={labelClass}>Age</label>
                    <input type="number" name="age" id="age" value={formData.age || ''} onChange={handleChange} className={inputClass} />
                </div>
                 <div>
                    <label htmlFor="gender" className={labelClass}>Gender</label>
                    <input type="text" name="gender" id="gender" value={formData.gender || ''} onChange={handleChange} className={inputClass} />
                </div>
                 <div>
                    <label htmlFor="experience" className={labelClass}>Experience (Years)</label>
                    <input type="text" name="experience" id="experience" value={formData.experience || ''} onChange={handleChange} className={inputClass} />
                </div>

                {isStudent ? (
                    <>
                        <div>
                            <label htmlFor="skills" className={labelClass}>Skills</label>
                            <textarea name="skills" id="skills" value={formData.skills || ''} onChange={handleChange} rows={3} className={inputClass} />
                        </div>
                         <div>
                            <label htmlFor="certifications" className={labelClass}>Certifications</label>
                            <textarea name="certifications" id="certifications" value={formData.certifications || ''} onChange={handleChange} rows={3} className={inputClass} />
                        </div>
                         <div>
                            <label htmlFor="graduationYear" className={labelClass}>Graduation Year</label>
                            <input type="text" name="graduationYear" id="graduationYear" value={formData.graduationYear || ''} onChange={handleChange} className={inputClass} />
                        </div>
                    </>
                ) : (
                    <>
                        <div>
                            <label htmlFor="company" className={labelClass}>Company</label>
                            <input type="text" name="company" id="company" value={formData.company || ''} onChange={handleChange} className={inputClass} />
                        </div>
                         <div>
                            <label htmlFor="roleInCompany" className={labelClass}>Role</label>
                            <input type="text" name="roleInCompany" id="roleInCompany" value={formData.roleInCompany || ''} onChange={handleChange} className={inputClass} />
                        </div>
                         <div>
                            <label htmlFor="companyMail" className={labelClass}>Company Mail</label>
                            <input type="email" name="companyMail" id="companyMail" value={formData.companyMail || ''} onChange={handleChange} className={inputClass} />
                        </div>
                    </>
                )}

                <button onClick={handleSave} className="w-full bg-flame-orange text-white font-bold py-3 rounded-lg hover:bg-orange-600 transition duration-300">Save Details</button>
            </div>
        </div>
    );
};

// Notifications Screen
export const NotificationsScreen: React.FC<{ setView: (view: string) => void }> = ({ setView }) => {
    return (
        <div className="p-4 min-h-screen">
            <header className="flex items-center mb-8">
                <button onClick={() => setView('settings')} className="mr-4 text-flame-orange">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
                </button>
                <h1 className="text-2xl font-bold">Notifications</h1>
            </header>
            <div className="space-y-6">
                <div>
                    <h2 className="text-lg font-semibold text-flame-orange mb-2">Investor Interest</h2>
                    <p className="text-gray-400 p-4 bg-[#001e4c] rounded-lg">No new investor notifications.</p>
                </div>
                 <div>
                    <h2 className="text-lg font-semibold text-flame-orange mb-2">App Updates</h2>
                    <p className="text-gray-400 p-4 bg-[#001e4c] rounded-lg">You are on the latest version of BizSpark!</p>
                </div>
                 <div>
                    <h2 className="text-lg font-semibold text-flame-orange mb-2">Workshops</h2>
                    <p className="text-gray-400 p-4 bg-[#001e4c] rounded-lg">No upcoming workshops scheduled.</p>
                </div>
            </div>
        </div>
    );
};

// --- START: Mock Data for Opportunities ---
const workshops = [
  { title: "Startup Pitch Deck 101", description: "Learn how to craft a compelling pitch deck that grabs investor attention.", tag: "Free", icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 12l3-3 3 3 4-4M8 21l4-4 4 4M3 4h18M4 4h16v12a1 1 0 01-1 1H5a1 1 0 01-1-1V4z" /></svg> },
  { title: "Digital Marketing for Founders", description: "Master SEO, content marketing, and social media to grow your startup.", tag: "Paid", icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-2.236 9.168-5.514C18.358 1.84 17.642 1 16.5 1H4a1 1 0 00-1 1v10.586A2.277 2.277 0 003.223 14.8l.003.004c.092.092.19.173.29.252z" /></svg> },
];

const bootcamps = [
  { title: "AI Startup Accelerator", description: "An intensive 8-week program to build and launch your AI-powered venture.", tag: "Paid", icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg> },
  { title: "Idea to MVP Weekend", description: "Turn your idea into a minimum viable product in just one weekend. No code required.", tag: "Free", icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" /></svg> },
];

const mentors = [
  { name: "Priya Sharma", role: "Community Building & EdTech Growth", detail: "Founder of ConnectU, scaled it to 1M+ users.", action: "Connect" },
  { name: "Raj Singh", role: "Angel Investor in SaaS", detail: "Early investor in 10+ successful B2B SaaS companies.", action: "Connect" },
];

const investors = [
    { name: "Anjali Mehta", role: "Innovate Capital", detail: "Focus: Supply Chain & Logistics, CleanTech", action: "View Profile" },
    { name: "Vikram Desai", role: "Future Ventures", detail: "Focus: Impact Investing, FinTech", action: "View Profile" },
];
// --- END: Mock Data for Opportunities ---

const OpportunityCard: React.FC<{ title: string; description: string; tag: string; icon: React.ReactNode }> = ({ title, description, tag, icon }) => (
    <div className="bg-[#001e4c] p-4 rounded-lg border border-gray-700 hover:border-flame-orange/50 transition-all">
        <div className="flex items-start gap-4">
            <div className="text-flame-orange mt-1 flex-shrink-0">{icon}</div>
            <div>
                <div className="flex justify-between items-center">
                    <h3 className="font-bold text-white">{title}</h3>
                    <span className={`text-xs font-semibold px-2 py-1 rounded-full ${tag === 'Free' ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'}`}>
                        {tag}
                    </span>
                </div>
                <p className="text-sm text-gray-400 mt-1">{description}</p>
            </div>
        </div>
    </div>
);

const PersonCard: React.FC<{ name: string, role: string, detail: string, actionText: string }> = ({ name, role, detail, actionText }) => (
    <div className="bg-[#001e4c] p-4 rounded-lg border border-gray-700 flex items-center justify-between gap-4">
        <div className="flex-1">
            <h3 className="font-bold text-white">{name}</h3>
            <p className="text-sm text-flame-orange">{role}</p>
            <p className="text-xs text-gray-400 mt-1">{detail}</p>
        </div>
        <button className="bg-flame-orange/20 text-flame-orange font-semibold py-2 px-4 rounded-lg border border-flame-orange text-sm hover:bg-flame-orange hover:text-white transition-colors flex-shrink-0">
            {actionText}
        </button>
    </div>
);


export const OpportunitiesScreen: React.FC<{ user: User; setView: (view: string) => void; openChatbot: () => void; }> = ({ user, setView, openChatbot }) => {
    return (
        <Layout currentView="opportunities" setView={setView} openChatbot={openChatbot}>
            <div className="p-4 h-full overflow-y-auto">
                <header className="sticky top-0 bg-deep-blue/80 backdrop-blur-sm py-4 -mx-4 px-4 z-10">
                    <h1 className="text-2xl font-bold">Opportunities</h1>
                </header>
                
                <div className="space-y-10 pb-10">
                    <section>
                        <h2 className="text-xl font-bold text-flame-orange mb-4">Workshops</h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {workshops.map((item, index) => <OpportunityCard key={index} {...item} />)}
                        </div>
                    </section>
                    
                    <section>
                        <h2 className="text-xl font-bold text-flame-orange mb-4">Bootcamps</h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {bootcamps.map((item, index) => <OpportunityCard key={index} {...item} />)}
                        </div>
                    </section>

                    <section>
                        <h2 className="text-xl font-bold text-flame-orange mb-4">Find a Mentor</h2>
                        <div className="space-y-4">
                            {mentors.map((item, index) => <PersonCard key={index} name={item.name} role={item.role} detail={item.detail} actionText={item.action} />)}
                        </div>
                    </section>

                    <section>
                        <h2 className="text-xl font-bold text-flame-orange mb-4">Connect with Investors</h2>
                        <div className="space-y-4">
                            {investors.map((item, index) => <PersonCard key={index} name={item.name} role={item.role} detail={item.detail} actionText={item.action} />)}
                        </div>
                    </section>
                </div>
            </div>
        </Layout>
    );
};
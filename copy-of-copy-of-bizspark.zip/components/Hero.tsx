import React, { useState, useEffect, useCallback } from 'react';
import { Role, User, StartupIdea } from '../types';
import { IdeaCard } from './IdeaCard';
import { Layout } from './Footer';
import { generateInvestorFeed } from '../services/geminiService';
import { LoadingSpinner } from './LoadingSpinner';

// Combined Component for AuthScreen and InvestorDashboard
interface CombinedScreenProps {
  setView: (view: string) => void;
  setUser: (user: User) => void;
  isInvestorView?: boolean;
  // FIX: Made user prop optional to allow AuthScreen to be used without a logged-in user.
  user?: User;
}

export const AuthScreen: React.FC<CombinedScreenProps> = ({ setView, setUser, isInvestorView = false, user }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [role, setRole] = useState<Role>(Role.STUDENT);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (isLogin) {
      const lastEmail = localStorage.getItem('bizspark_last_email');
      if (lastEmail) {
        setEmail(lastEmail);
      }
    }
  }, [isLogin]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Please fill in all fields.');
      return;
    }
    setError('');
    // Mock authentication
    const mockUser: User = {
      id: `user_${Date.now()}`,
      email,
      role,
      profile: { name: '' },
      profileComplete: false,
    };
    if (setUser) {
        setUser(mockUser);
        localStorage.setItem('bizspark_user', JSON.stringify(mockUser));
    }
    setView('profileSetup');
  };
  
  if (isInvestorView) {
    const [isLoadingIdeas, setIsLoadingIdeas] = useState(true);

    if (!user || !setUser) {
      return (
        <Layout currentView="dashboard" setView={setView}>
          <div className="h-full flex items-center justify-center">
            <p className="text-gray-400">Loading user data...</p>
          </div>
        </Layout>
      );
    }
    
    const investorIdeas = user.investorFeed || [];

    const fetchInvestorIdeas = useCallback(async () => {
      if (!user.profile) return;
      setIsLoadingIdeas(true);
      try {
        const ideas = await generateInvestorFeed(user.profile);
        const updatedUser = { ...user, investorFeed: ideas };
        setUser(updatedUser);
      } catch (error) {
        console.error("Failed to fetch investor ideas:", error);
        const updatedUser = { ...user, investorFeed: [] };
        setUser(updatedUser);
      } finally {
        setIsLoadingIdeas(false);
      }
    }, [user, setUser]);

    useEffect(() => {
        if (!user.investorFeed || user.investorFeed.length === 0) {
            fetchInvestorIdeas();
        } else {
            setIsLoadingIdeas(false);
        }
    }, [fetchInvestorIdeas, user.investorFeed]);
    
    const handleSaveIdea = (ideaToSave: StartupIdea) => {
        const alreadySaved = user.savedIdeas?.some(i => i.ideaName === ideaToSave.ideaName);
        if (alreadySaved) return;

        const updatedSavedIdeas = [...(user.savedIdeas || []), ideaToSave];
        const updatedUser = { ...user, savedIdeas: updatedSavedIdeas };
        setUser(updatedUser);
    };

    return (
        <Layout currentView="dashboard" setView={setView}>
            <div className="h-full bg-deep-blue p-4 overflow-y-auto">
                <header className="p-4 flex justify-between items-center">
                    <h1 className="text-2xl font-bold text-white">Investor Dashboard</h1>
                    <button onClick={fetchInvestorIdeas} disabled={isLoadingIdeas} className="text-sm bg-flame-orange/20 text-flame-orange font-semibold py-2 px-4 rounded-lg border border-flame-orange transition-colors disabled:opacity-50 enabled:hover:bg-flame-orange enabled:hover:text-white">
                        {isLoadingIdeas ? 'Refreshing...' : 'Refresh Feed'}
                    </button>
                </header>
                <main className="container mx-auto py-4">
                     <p className="text-lg text-gray-300 mb-8 px-4">
                        Curated opportunities based on your focus: <span className="font-semibold text-flame-orange">{user.profile.focusAreas || 'General Tech'}</span>
                    </p>
                    {isLoadingIdeas ? (
                        <div className="flex justify-center items-center h-64">
                            <LoadingSpinner />
                        </div>
                    ) : investorIdeas.length > 0 ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {investorIdeas.map((idea, index) => (
                                <IdeaCard 
                                    key={index} 
                                    idea={idea} 
                                    onSave={handleSaveIdea} 
                                    isSaved={user.savedIdeas?.some(i => i.ideaName === idea.ideaName)} 
                                />
                            ))}
                        </div>
                    ) : (
                        <div className="text-center text-gray-400 mt-20 flex flex-col items-center">
                           <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-gray-500 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
                           <h3 className="text-xl font-semibold mb-2">No New Opportunities</h3>
                           <p>We couldn't find any new startup ideas matching your profile right now. Try refreshing the feed.</p>
                        </div>
                    )}
                </main>
            </div>
        </Layout>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-deep-blue">
      <div className="w-full max-w-md mx-auto bg-[#001e4c] p-8 rounded-2xl shadow-2xl border border-gray-700">
        <h2 className="text-3xl font-bold text-center text-white mb-2">{isLogin ? 'Welcome Back' : 'Create Account'}</h2>
        <p className="text-center text-gray-400 mb-6">Let's get you started.</p>
        
        {!isLogin && (
          <div className="flex bg-deep-blue p-1 rounded-lg mb-6">
            <button onClick={() => setRole(Role.STUDENT)} className={`w-1/2 p-2 rounded-md font-semibold transition ${role === Role.STUDENT ? 'bg-flame-orange text-white' : 'text-gray-300'}`}>I'm a Student</button>
            <button onClick={() => setRole(Role.INVESTOR)} className={`w-1/2 p-2 rounded-md font-semibold transition ${role === Role.INVESTOR ? 'bg-flame-orange text-white' : 'text-gray-300'}`}>I'm an Investor</button>
          </div>
        )}

        <form onSubmit={handleSubmit}>
            {error && <p className="text-red-400 text-center mb-4">{error}</p>}
          <div className="mb-4">
            <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-2">Email</label>
            <input type="email" id="email" value={email} onChange={e => setEmail(e.target.value)} className="w-full bg-deep-blue border border-gray-600 rounded-lg p-3 focus:ring-2 focus:ring-flame-orange focus:border-flame-orange" />
          </div>
          <div className="mb-6">
            <label htmlFor="password" className="block text-sm font-medium text-gray-300 mb-2">Password</label>
            <input type="password" id="password" value={password} onChange={e => setPassword(e.target.value)} className="w-full bg-deep-blue border border-gray-600 rounded-lg p-3 focus:ring-2 focus:ring-flame-orange focus:border-flame-orange" />
          </div>
          <button type="submit" className="w-full bg-flame-orange text-white font-bold py-3 rounded-lg hover:bg-orange-600 transition duration-300">{isLogin ? 'Log In' : 'Sign Up'}</button>
        </form>
        
        <p className="text-center text-sm text-gray-400 mt-6">
          {isLogin ? "Don't have an account?" : "Already have an account?"}
          <button onClick={() => setIsLogin(!isLogin)} className="font-semibold text-flame-orange hover:text-orange-400 ml-1">
            {isLogin ? 'Sign Up' : 'Log In'}
          </button>
        </p>
      </div>
    </div>
  );
};
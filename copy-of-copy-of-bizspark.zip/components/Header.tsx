import React from 'react';
import { ThemeDropIcon } from './ThemeDropIcon';

interface WelcomeScreenProps {
  setView: (view: string) => void;
}

const investors = [
  {
    name: "Anya Sharma",
    focus: "Early-Stage SaaS & FinTech",
    bio: "A former founder with two successful exits, Anya is passionate about helping early-stage B2B startups with product-market fit and go-to-market strategy.",
    initials: "AS"
  },
  {
    name: "Rohan Das",
    focus: "Deep Tech & AI",
    bio: "With a PhD in Machine Learning, Rohan backs ambitious founders building category-defining companies in AI, robotics, and quantum computing.",
    initials: "RD"
  },
  {
    name: "Meera Kapoor",
    focus: "Sustainability & Social Impact",
    bio: "Meera leads an impact fund dedicated to startups that address climate change, circular economy, and social equity. She seeks mission-driven teams.",
    initials: "MK"
  },
  {
    name: "Vikram Chen",
    focus: "Consumer Tech & D2C Brands",
    bio: "An expert in brand building and viral marketing, Vikram invests in disruptive consumer products and platforms that capture the hearts of millennials and Gen Z.",
    initials: "VC"
  }
];

const InvestorCard: React.FC<typeof investors[0]> = ({ name, focus, bio, initials }) => (
    <div className="bg-[#001e4c]/80 border border-gray-700 rounded-2xl p-6 text-left transform hover:-translate-y-2 transition-transform duration-300 h-full flex flex-col">
        <div className="flex items-center mb-4">
            <div className="w-16 h-16 rounded-full bg-flame-orange flex-shrink-0 flex items-center justify-center text-white text-2xl font-bold mr-4">
                {initials}
            </div>
            <div>
                <h3 className="text-xl font-bold text-white">{name}</h3>
                <p className="text-sm text-flame-orange font-semibold">{focus}</p>
            </div>
        </div>
        <p className="text-gray-400 text-sm">
            {bio}
        </p>
    </div>
);


export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ setView }) => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 text-center bg-deep-blue">
       <div className="flex flex-col items-center justify-center flex-grow pt-12">
        <ThemeDropIcon className="w-48 h-auto mb-6" />
        <h1 className="text-5xl md:text-6xl font-extrabold text-white tracking-tight">
            Welcome to <span className="text-flame-orange">BizSpark</span>
        </h1>
        <p className="mt-4 max-w-2xl text-lg md:text-xl text-gray-300">
            Your AI co-pilot for turning brilliant ideas into successful startups. Connect, create, and innovate.
        </p>
        <div className="mt-10">
            <button
            onClick={() => setView('auth')}
            className="px-10 py-4 text-lg font-bold text-white bg-flame-orange rounded-lg shadow-lg hover:bg-orange-600 transform hover:scale-105 transition-all duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-deep-blue focus:ring-orange-400"
            >
            Get Started
            </button>
        </div>
      </div>
      
      <div className="w-full max-w-7xl mx-auto px-4 py-16">
          <h2 className="text-4xl font-extrabold text-white text-center">
              Invest With <span className="text-flame-orange">Us</span>
          </h2>
          <p className="mt-4 max-w-3xl mx-auto text-center text-lg text-gray-300">
              Join a curated network of venture capitalists and angel investors backing the next generation of student innovators.
          </p>
          <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {investors.map(investor => <InvestorCard key={investor.name} {...investor} />)}
          </div>
      </div>

      <div className="text-sm text-gray-400 pb-6">
        <button onClick={() => setView('terms')} className="underline hover:text-white mx-2">Terms & Conditions</button>
        |
        <button onClick={() => setView('privacy')} className="underline hover:text-white mx-2">Privacy Policy</button>
      </div>
    </div>
  );
};